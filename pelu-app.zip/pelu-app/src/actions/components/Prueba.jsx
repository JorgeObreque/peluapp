import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Prueba = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8000/api/getUsers')
      .then(response => {
        setData(response.data);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);

  return (
    <div>
        {data.map(item => (
        <p key={item.id}>{item.name}</p>
        ))}
  </div>
  );
};

export default Prueba;